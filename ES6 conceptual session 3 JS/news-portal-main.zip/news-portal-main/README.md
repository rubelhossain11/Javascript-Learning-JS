# news-portal

## API Links

## All News Category
url: https://openapi.programming-hero.com/api/news/categories

### All news in a Category
URL Format: https://openapi.programming-hero.com/api/news/category/{category_id} 

Example: https://openapi.programming-hero.com/api/news/category/01


### News detail url:
URL Format:  https://openapi.programming-hero.com/api/news/{news_id} 


Example: https://openapi.programming-hero.com/api/news/0282e0e58a5c404fbd15261f11c2ab6a

### Missing Data: 
Here total view and author name is null
https://openapi.programming-hero.com/api/news/2e78e5e0310c2e9adbb6efb1a263e745 
