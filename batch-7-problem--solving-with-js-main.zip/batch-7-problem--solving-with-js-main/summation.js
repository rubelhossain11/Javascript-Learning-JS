/* 1 to n
1+2+3+.....+n =
*/
// n(n+1)/2
// let num1 = 1;
// let num2 = 2;

// let sum = 0;

// sum = num1+num2;

// console.log(sum);
// n=5
// 1+2+3+4+5
// n=10
// 1+2+3+4+5+6+7+8+9+10
// sum = 0, 1
// sum = sum +i //      sum = 1+2
let n= 10;
let sum =0;
for(let i=1; i<=n;i++){
    sum = sum + i;
}
console.log(sum);
// 1+2+3 = 6
// sum =0
// i =4
// sum = 3+ 3; sum =6
// let n= 3;
// let sum =0;
// for(let i=1; i<=n;i++){
//     sum = sum + i;
// }
// console.log(sum);


// let sum2 = (n*(n+1))/2;
// console.log("sum2", sum2)



