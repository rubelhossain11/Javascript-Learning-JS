/* 
1 * 3 = 3
2 * 3 = 6
3 * 3 = 9
4 * 3 = 12
5 * 3 = 15
6 * 3 = 18
7 * 3 = 21
8 * 3 = 24
9 * 3 = 27
10 * 3 = 30
*/

let num1 = 1;
let num2 = 3;

let product = num1 * num2;
// console.log(product)


/* 
1 *3
2 *3
3 *3
4 *3
*/

for( let i =1; i<=10; i++){
    console.log(i + "*" + 3+" = " + i*3)
}


// let a = "programming"
// let b =1

// console.log(a+b);